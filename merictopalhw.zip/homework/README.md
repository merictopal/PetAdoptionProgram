# Pet Portal Skeleton

Start implementing features based on the assignment instructions.\
You don't have to do any styling, focus on the functionalities.\
Feel free to create new files for more organized code.

## Developing
```bash
	npm run dev
```
Install dependencies:
```bash
	npm i
```
